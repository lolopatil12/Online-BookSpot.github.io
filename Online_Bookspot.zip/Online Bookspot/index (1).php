
<?php
ob_start();
// include header.php file
include ('header.php');
?>    

<?php

/*  include banner area  */
    include ('Template/_banner-area.php');
/*  include banner area  */

     include ('Template/feature.php');

/*  include top sale section */
        include ('Template/_top-sale.php');
    /*  include top sale section */

    include ('Template/deal.php');
    

      /*  include new books section  */
        include ('Template/_new-books.php');
    /*  include new books section  */

      ?>
    
    <?php
// include footer.php file
include ('Footer.php');
?>
