<?php
// include header.php file
include ('header.php');
 ?>
 <br>
 <br>
 <?php

/*  include category section  */
    include ('Template/_category.php');
    /*  include category section  */
    ?> 
    <?php
// include footer.php file
include ('Footer.php');
?>
