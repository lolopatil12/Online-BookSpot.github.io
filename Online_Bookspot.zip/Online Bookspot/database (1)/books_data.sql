-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2020 at 11:01 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopee`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `item_id` int(11) NOT NULL,
  `item_brand` varchar(200) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `item_price` double(10,2) NOT NULL,
  `item_image` varchar(255) NOT NULL,
  `item_register` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`item_id`, `item_brand`, `item_name`, `item_price`, `item_image`, `item_register`) VALUES
(1, 'Art', '7 Secrets Of Shiva', 420.00, './assets/1.jpg', '2021-09-28 11:08:57'), -- NOW()
(2, 'Art', 'Paris Library', 122.00, './assets/2.jpg', '2021-09-28 11:08:57'),
(3, 'Art', 'The Mourya Empire', 280.00, './assets/3.jpg', '2021-09-28 11:08:57'),
(4, 'Art', 'What Comes After', 300.00, './assets/4.jpg', '2021-10-04 11:08:57'),
(5, 'Art', 'Anatomy', 270.00, './assets/5.jpg', '2021-10-04 11:08:57'),
(6, 'Cooking', 'Tiffin', 120.00, './assets/6.jpg', '2021-10-04 11:08:57'),
(7, 'Comedy', 'A Nation of Idiots', 370.00, './assets/7.jpg', '2021-10-04 11:08:57'),
(8, 'Cooking', 'Thai Cookery Secrets', 220.00, './assets/8.jpg', '2021-10-04 11:08:57'),
(9, 'Art', 'History of Indian Art', 499.00, './assets/9.jpg', '2021-10-04 11:08:57'),
(10, 'Cooking', '2 Minutes is Enough', 400.00, './assets/10.jpg', '2021-10-04 11:08:57'),
(11, 'Horror', 'Olympus', 140.00, './assets/11.jpg', '2021-10-04 11:08:57'),
(12, 'Cooking', 'Cake Baking Book', 152.00, './assets/12.jpg', '2021-10-04 11:08:57'),
(13, 'Horror', 'The Darkest Secret', 565.00, './assets/13.jpg', '2021-10-04 11:08:57'),
(14, 'Comedy', 'Happiness', 130.00, './assets/14.jpg', '2021-10-04 11:08:57'),
(15, 'Horror', 'Ghosts of The Silent Hills', 350.00, './assets/15.jpg', '2021-10-04 11:08:57'),
(16, 'Comedy', 'Memes 2021', 120.00, './assets/16.jpg', '2021-10-04 11:08:57'),
(17, 'Comedy', 'Tongue In Cheek', 450.00, './assets/17.jpg', '2021-10-04 11:08:57'),
(18, 'Comedy', 'Speak Out', 340.00, './assets/18.jpg', '2021-10-04 11:08:57'),
(19, 'Horror', 'House in Salt', 200.00, './assets/19.jpg', '2021-10-04 11:08:57'),
(20, 'Horror', 'The Devil and The Dark Water', 210.00, './assets/20.jpg', '2021-10-04 11:08:57'),
(21, 'Horror', 'Horror Stories', 440.00, './assets/21.jpg', '2021-10-04 11:08:57'),
(22, 'Horror', 'Almost Dark', 290.00, './assets/22.jpg', '2021-10-04 11:08:57'),
(23, 'Cooking', 'Pakodas', 430.00, './assets/23.jpg', '2021-10-04 11:08:57'),
(24, 'Horror', 'The Wife Upstairs', 140.00, './assets/24.jpg', '2021-10-04 11:08:57'),
(25, 'Comedy', 'Doing Good', 320.00, './assets/25.jpg', '2021-10-04 11:08:57')
-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `register_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `first_name`, `last_name`, `register_date`) VALUES
(1, 'Vibhakti', 'Patil', '2020-03-28 13:07:17'),
(2, 'Shruti', 'Patil', '2020-03-28 13:07:17');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;