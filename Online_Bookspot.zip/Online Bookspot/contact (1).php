    
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bookspot</title>
    <link rel="stylesheet" href="contact.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body>
      <!--contact section start-->
    <div class="contact-section">
      <div class="contact-info">
        <div ><i class="fa fa-map-marker" ></i>Vileparle,Anderi</div>
        <div><i class="fa fa-envelope"></i>bookspot@email.com</div>
        <div><i class="fa fa-phone" ></i>+9867546484</div>
        </div>
        <div class="icons">
          <a href="#"><i class="fa fa-facebook" ></i></a>
          <a href="#"><i class="fa fa-instagram" ></i></a>
         <a href="#"><i class="fa fa-linkedin" ></i></a>

       </div>
        </div>
      <div class="contact-form">
        <h2>Contact Us</h2>
        <form class="contact" action="" method="post">
          <input type="text" name="name" class="text-box" placeholder="Your Name" required>
          <input type="email" name="email" class="text-box" placeholder="Your Email" required>
          <textarea name="message" rows="5" placeholder="Your Message"></textarea>
          <input type="submit" name="submit" class="send-btn" value="Send">
        </form>
      </div>
  </body>
</html>
