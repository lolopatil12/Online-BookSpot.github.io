<!DOCTYPE html>
<html>

<head>
    <title>Admin</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js"></script>

    <link rel="stylesheet" href="style.css">
</head>

<body>

    <nav class="navbar navbar-light bg-light border-bottom">
        <div class="container-fluid">
            <a class="navbar-brand" href="db.php"><i class="fas fa-book text-success"></i> <b>Bookspot</b></a>
            <form class="d-flex">
                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                <button class="btn btn-outline-success" type="submit"><i class="fas fa-search"></i></button> &nbsp
                <button class="btn btn-outline-success" type="submit">Logout</button>
            </form>
        </div>
    </nav>
    <div class="wrapper">

        <nav id="sidebar" class="border">
            <ul class="lisst-unstyled components">

                <li>
                    <a href="profile.php">Your Profile</a>
                </li>
                <li>
                    <a href="db.php">Dashboard</a>
                </li>
                <li>
                    <a href="orders.php">Orders</a>
                </li>
                <li>
                    <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false"
                        class="dropdown-toggle">Categories</a>
                    <ul class="collapse list-unstyled" id="pageSubmenu">
                        <li>
                            <a href="comedy.php">Comedy</a>
                        </li>
                        <li>
                            <a href="cooking.php">Cooking</a>
                        </li>
                        
                        <li>
                            <a href="arts.php">Arts</a>
                        </li>
                        <li>
                            <a href="horror.php">Horror</a>
                        </li>
                        
                      
                    </ul>
                </li>
                <li>
                    <a href="user_queries.php">User Queries</a>
                </li>
                <li>
                    <a href="products.php">Products</a>
                </li>

            </ul>
        </nav>
        <div id="content" >
            <nav class="navbar navbar-expand-lg navbar-light">
                <div class="container-fluid" style="color:blue">

                    <button type="button" id="sidebarCollapse" class="btn" style="background-color:#419121; color:white">
                        <i class="fas fa-align-left"></i>
                        <span>Toggle Sidebar</span>
                    </button>
                </div>
            </nav>

