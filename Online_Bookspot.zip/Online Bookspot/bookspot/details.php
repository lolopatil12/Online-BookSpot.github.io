<?php
 include ('header.php');
?>        <br><br>
        <table class="table">
        <thead class="table-secondary" style="height:40px">
				<tr>
					<th scope="col" style="width:200px"> Customer</th>
					<th scope="col" style="width:200px">product</th>

				</tr>
				</thead>
				<tbody>
                <?php
			                                $con=mysqli_connect('localhost','root');
                                            mysqli_select_db($con,'bookspot');
            
                                            $ids=$_GET['id'];
                                            $showquery="select * from orders where cust_id={$ids}";
                                                       $result=mysqli_query($con,$showquery);                                  
                                
                                                        //$row =mysqli_num_rows($querydisplay);
                                                         $arrdata=mysqli_fetch_array($result);
                                               ?>
					
												<tr>
													<td>
                                                    <label style="font-size:20px"><b>username:</b> <?php echo $arrdata['user_name'];?><br>
                                                    <label style="font-size:20px"><b>mobile:</b> <?php echo $arrdata['mobile'];?><br>
                                                    <label style="font-size:20px"><b>Address: </b><?php echo $arrdata['address'];?></td>
													<td> <label style="font-size:20px"><b>product id: </b> <?php echo$arrdata['isbn'];?> <br>
                                                    <label style="font-size:20px"><b>product:</b> <?php echo $arrdata['product_name'];?>
                                                <br>
                                                <b>quantity:  </b> <?php echo $arrdata['quantity'];?></td>
                                                   
                                                   
												</tr>
				</tbody>
             </table>
       
         
               

               
								


        </div>
        
    </div>










    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>

    <script>

        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });

    </script>


</body>

</html> 