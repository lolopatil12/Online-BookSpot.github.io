<?php
 include ('header.php');
?>
            <br>
            <div class="container">
			 
                <table class="table table-bordered border-dark">
                    <thead class="table-secondary">
                    <tr>
                        <th scope="col" style="width:170px">User_Id</th>
                        <th scope="col" style="width:130px">First_Name</th>
                        <th scope="col" style="width:200px">Last_Name</th>
                        <th scope="col" style="width:200px">Register_Date</th>
              
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                                           $con=mysqli_connect('localhost','root');
                                           mysqli_select_db($con,'bookspot');
                                   
                                           $query="select * from user";
                                           $query_run=mysqli_query($con,$query);
                                           $check_product=mysqli_num_rows($query_run)>0;
                                   
                                           if($check_product){
                                               while($row=mysqli_fetch_array($query_run)){
                                                   ?>
                        
                                                    <tr>
                                                        <td> <?php echo $row['user_id'];?></td>
                                                        <td>  <?php echo$row['first_name'];?> </td>
                                                         <td>   <?php echo $row['first_name'];?></td>
                                                         <td>   <?php echo $row['register_date'];?></td>
                                                    </tr>
                                                    <?php
                                                }
                                            }
                        ?>
                    </tbody>
                 </table>
          
	
            </div>
		<br><br><br>

        </div>
        
    </div>




    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>

    <script>

        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });

    </script>


</body>

</html>