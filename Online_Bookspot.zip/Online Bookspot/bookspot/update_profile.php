
<?php
 include ('header.php');
?>            <br>
            <form method="post"  enctype="multipart/form-data" class="form col-lg-8">
            <?php
                                $con=mysqli_connect('localhost','root');
                                mysqli_select_db($con,'admin');
                                
                                $ids=$_GET['id'];

                                $showquery="select * from login where id={$ids}";
                                $result=mysqli_query($con,$showquery);

                                $arrdata=mysqli_fetch_array($result);

                                if(isset($_POST['submit'])){

                                    $idupdate=$_GET['id'];

                                    $user=$_POST['user'];
                                    $pass=$_POST['pass'];
                                    $email=$_POST['email'];
                                    


                        
                                    $q="UPDATE `login` SET `user`='$user',`pass`='$pass',`email`='$email' WHERE id='$idupdate'";
                                    $query=mysqli_query($con,$q);

                                    if($query){
                                        header('location:profile.php');
                                    }
       
                                    
                                }
    
			                	?>
     
                                    <div class="form-group">
                                        <label>Username:</label>
                                        <input type="text" class="form-control" name="user"  value="<?php echo $arrdata['user'];?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Password:</label>
                                        <input type="text" class="form-control" name="pass"  value="<?php echo $arrdata['pass'];?>">
                                    </div>

                                    <div class="form-group">
                                        <label>Email:</label>
                                        <input type="text" class="form-control" name="email"  value="<?php echo $arrdata['email'];?>">
                                    </div>
                                    <button class="btn btn-success" name="submit"> update </button>
                                <a href="profile.php"><button class="btn btn-success"> Cancel</button><a>
</form>
        </div>
</div>

        
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>

    <script>

        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });

    </script>

</body>
    </html>