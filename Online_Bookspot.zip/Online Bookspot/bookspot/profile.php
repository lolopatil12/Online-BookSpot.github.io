
<?php
 include ('header.php');
?>
            <br>
            <form method="post"  enctype="multipart/form-data" class="form col-lg-8">
            <?php
                                $con=mysqli_connect('localhost','root');
                                mysqli_select_db($con,'admin');
                                $displayquery="SELECT * FROM login ";
                                $querydisplay=mysqli_query($con,$displayquery);
                                $result=mysqli_fetch_array($querydisplay);

                               
    
			                	?>
     
                                    <div class="form-group">
                                    <i class="fas fa-user"></i>  <label>Username:</label>
                                        <input type="text" class="form-control" name="user" disabled value="<?php echo $result['user'];?>">
                                    </div>
                                    <div class="form-group">
                                    <i class="fas fa-key"></i> <label>Password:</label>
                                        <input type="text" class="form-control" name="pass" disabled value="<?php echo $result['pass'];?>">
                                    </div>

                                    <div class="form-group">
                                    <i class="fas fa-envelope"></i> <label>Email:</label>
                                        <input type="text" class="form-control" name="email" disabled value="<?php echo $result['email'];?>">
                                    </div>
                                   
                                    <button class="btn btn-success" name="submit"> <a href="update_profile.php? id=<?php echo $result['id'];?>" >update </a></button>
                                <button class="btn btn-success"> Cancel</button>

                                
</form>
        </div>
</div>

        
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>

    <script>

        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });

    </script>

</body>
    </html>