<?php
 $con=mysqli_connect('localhost','root');
 mysqli_select_db($con,'bookspot');

 $id=$_GET['id'];
 $qu="DELETE FROM `product` WHERE item_id=$id";
 mysqli_query($con,$qu);
 header('location:products.php');
?>