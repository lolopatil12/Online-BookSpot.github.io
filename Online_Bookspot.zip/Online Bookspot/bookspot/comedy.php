
<?php
 include ('header.php');
?>
            <br>
            <div class="container">
			  <h2 style="font-family:times new roman">Comedy</h2>
			  <hr>
			<button class="btn btn-success" data-target="#mymodel" data-toggle="modal" style="float: right; "> Add Book</button>
			<div class="modal " id="mymodel">
				<div class="modal-dialog modal-dialog-centered">
					<div class="modal-content ">
						<div class="modal-header">
							<h3 class="text-center"> Add Book</h3>
							<button class="close" data-dismiss="modal"> &times;</button>
						</div>
						<div class="modal-body">
                        <form method="post"  enctype="multipart/form-data" class="form">
                                    <div class="form-group">
                                        <label>Title:</label>
                                        <input type="text" class="form-control" name="title" >
                                    </div>
                                    <div class="form-group">
                                        <label>Category:</label><br>
                                        <select name="category" id="category" style=" height:40px" >
                                            <option value="Choose">Choose</option>
                                            <option value="Comedy">Comedy</option>
                                            <option value="Art">Art</option>
                                            <option value="Cooking">Cooking</option>
                                            <option value="Horror">Horror</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Price:</label>
                                        <input type="text" class="form-control" name="price" >
                                    </div>
                                    
                                    <div class="form-group">
                                        <label>Upload Images:</label>
                                        <input type="file" class="form-control" name="file" >
                                    </div>
                                
                            <div class="modal-footer justify-content-center">
                                <input type="submit" name="submit" class="btn btn-success"  > </button>
                                <button class="btn btn-success" data-dismiss="modal"> Cancel</button>
                            </div>
                            <?php
                                  $con=mysqli_connect('localhost','root');
                                  mysqli_select_db($con,'bookspot');

                                if(isset($_POST['submit'])){
                                    $title=$_POST['title'];
                                    $cat=$_POST['category'];
                                    $price=$_POST['price'];
                                    $image=$_FILES['file'];
                                   

                                    $img_loc = $_FILES['file']['tmp_name'];
                                    $img_name = $_FILES['file']['name'];
                                    $img_des="./assets/".$img_name;
                                    move_uploaded_file($img_loc,'./assets/'.$img_name); 

                                    //insert data

                                    mysqli_query($con,"INSERT INTO `product`( `item_id`,`item_brand`, `item_name`, `item_price`, `item_image`) VALUES ('$isbn','$cat','$title','$price','$img_des')");
                                }
				            ?>
                            </form>
						</div>
					</div>
				</div>
			</div>
            </div>
		<br><br><br>
		
        <table class="table table-bordered border-dark" id="myTable">
				<thead class="table-secondary">
				<tr>
					<th scope="col" style="width:170px">Name</th>
					<th scope="col" style="width:130px">Block Image</th>
					<th scope="col" style="width:100px">Price</th>
					<th scope="col" style="width:150px">Category</th>
					<th scope="col" style="width:150px"></th>
				</tr>
				</thead>
				<tbody>
					
				<?php
					                         $con=mysqli_connect('localhost','root');
                                             mysqli_select_db($con,'bookspot');

                                            $displayquery="SELECT * FROM PRODUCT WHERE item_brand='comedy' ";
											$querydisplay=mysqli_query($con,$displayquery);
					
											//$row =mysqli_num_rows($querydisplay);
					
											while($result=mysqli_fetch_array($querydisplay)){
												?>
					
												<tr>
													<td> <?php echo $result['item_name'];?></td>
													<td> <img src="<?php echo $result['item_image'];?>" height="150px" width="100px"></td>
													<td> <?php echo $result['item_price'];?></td>
													<td> <?php echo $result['item_brand'];?></td>
													<td><button class="btn bg-light"><a href="delete.php? id=<?php echo $result['item_id'];?>" ><i class="fas fa-trash-alt"> </i></a></button>
													<button class="btn bg-light"><a href="update.php? id=<?php echo $result['item_id'];?>" data-toggle="tooltip" data-placement="bottom" title="UPDATE"><i class="fas fa-pen"></i> </a></button></td>
													
												</tr>
												<?php
											}
                                     
					?>
				</tbody>
             </table>
        </div>
        
    </div>



<script>
    const searchFun = () =>{
        let filter = document.getElementById('myInput').value.toUpperCase();

        let myTable = document.getElementById('myTable');

        let tbody = myTable.getElementsByTagName('tbody');

        let tr = myTable.getElementsByTagName('tr');

        for(var i=0; i<tr.length; i++){
            let td = tr[i].getElementsByTagName('td')[0];

            if(td){
                let textvalue = td.textContent || td.innerHTML ;

                if(textvalue.toUpperCase().indexOf(filter) > -1){
                    tr[i].style.display="";
                }else{
                    tr[i].style.display="none";
                }
                
            }
        }

        
    }
</script>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>

    <script>

        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });

    </script>


</body>

</html>