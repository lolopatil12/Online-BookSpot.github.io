<?php
session_start();
$con=mysqli_connect('localhost','root','');
if($con){
  //  echo "connection successful";
}else{
    echo "no connection";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link rel="stylesheet" type="text/css" href="login.css">
    <?php include 'links.php' ?>
</head>
<body>
    <header>
        <div class="container center-div shadow mb-5">
            <div class="heading text-center text-uppercase text-white mb-5">
                Admin Login Page
            </div>
            <img src="./assets/login-logo.png" style="position: center;">
            <div class="container row d-flex flex-row justify-content-center mb-5">
                <div class="admin-form shadow p-2">
                    <form action="logincheck.php" method="POST">
                        <div class="form-group">
                            <label>Username </label>
                            <input type="text" name="user" value="" class="form-control" placeholder="Please Enter Username" autocomplete="off">
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="pass" value="" class="form-control"placeholder="Please Enter Password" autocomplete="off">
                        </div>
                        <input type="submit" class="btn btn-success" name="submit">
                    </form>
                </div>
            </div>
        </div>
    </header>
</body>
</html>