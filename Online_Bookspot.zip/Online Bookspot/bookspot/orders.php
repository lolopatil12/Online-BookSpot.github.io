<?php
 include ('header.php');
?>
        <div class="container py-5">
    <div class="row mt-4">
        <?php 
        $con=mysqli_connect('localhost','root');
        mysqli_select_db($con,'admin');

        $query="select * from orders";
        $query_run=mysqli_query($con,$query);
        $check_product=mysqli_num_rows($query_run)>0;

        if($check_product){
            while($row=mysqli_fetch_array($query_run)){
                ?>
                <div class="col-md-3 mt-3" >
                    <div class="card " >
                        <div class="card-body">
                            <h4 class="card-title"><?php  echo $row['cust_id']; ?></h4>
                            <h5 class="card-title"><?php  echo $row['product_name']; ?></h5>
                            <h6 class="card-title"><?php  echo $row['isbn']; ?></h6>

                        </div>
                    </div>
                </div>
                <?php
                
            }
        }else{
            echo"no record found";
        }
        ?>
        
    </div>
</div>
        </div>
        
    </div>










    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>

    <script>

        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });

    </script>


</body>

</html> 