
<?php
 include ('header.php');
?>
            <br>
            <form method="post"  enctype="multipart/form-data" class="form col-lg-8">
            <?php
                                $con=mysqli_connect('localhost','root');
                                mysqli_select_db($con, 'bookspot');

                                $ids=$_GET['id'];

                                $showquery="select * from product where item_id={$ids}";
                                $showdata=mysqli_query($con,$showquery);

                                $arrdata=mysqli_fetch_array($showdata);

                                if(isset($_POST['submit'])){

                                    $idupdate=$_GET['id'];
                                    $title=$_POST['title'];
                                    $cat=$_POST['category'];
                                    $price=$_POST['price'];
                                                            
                                    $q="UPDATE `product` SET `item_brand`='$cat',`item_name`='$title',`item_price`='$price' WHERE item_id='$idupdate'";
                                    
                                    $query=mysqli_query($con,$q);
		
                                    if($query){
                                        header('location:products.php');
                                    }
       
                                    }

                                    
			                	?>
                                    <div class="form-group">
                                        <label>Title:</label>
                                        <input type="text" class="form-control" name="title" value="<?php echo $arrdata['item_name'];?>">
                                    </div>
                                    <div class="form-group">
                                        <label>Category:</label><br>
                                        <select name="category" id="category" style=" height:40px" >
                                            <option ><?php echo $arrdata['item_brand'];?></option>
                                            <option value="Comedy">Comedy</option>
                                            <option value="Art">Art</option>
                                            <option value="Cooking">Cooking</option>
                                            <option value="Horror">Horror</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Price:</label>
                                        <input type="text" class="form-control" name="price" value="<?php echo $arrdata['item_price'];?>">
                                    </div>
                                    
                                    <button class="btn btn-success" name="submit"> update</button>
                                <button class="btn btn-success"> Cancel</button>
</form>
        </div>
</div>

        
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>

    <script>

        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });

    </script>

</body>
    </html>