<?php
 $con=mysqli_connect('localhost','root');
 mysqli_select_db($con,'admin');

 $id=$_GET['id'];
 $qu="DELETE FROM `user_queries` WHERE id=$id";
 mysqli_query($con,$qu);
 header('location:user_queries.php');
?>