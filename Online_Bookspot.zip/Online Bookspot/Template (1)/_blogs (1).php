 <!-- Blogs -->
 <section id="blogs">
        <div class="container-fluid ">
        <h1 class="heading"> <span>Our Blogs</span> </h1>
          <hr>
          <div class="owl-carousel owl-theme">
            <div class="item">
              <div class="card border-0 font-rale mr-5" style="width: 30rem;">
                <h5 class="card-title font-size-16 ">Books</h5>
                <img src="./assets/blogs/blog-1.jpg" alt="cart image" class="card-img-top">
                <p class="card-text font-size-14  py-1">Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis non iste sequi cupiditate tempora iure. Velit accusamus saepe harum sed.</p>
                <a href="#" class="color-second text-left">Go somewhere</a>
              </div>
            </div>
            <div class="item">
              <div class="card border-0 font-rale mr-5" style="width: 30rem;">
                <h5 class="card-title font-size-16 ">Books</h5>
                <img src="./assets/blogs/blog-2.jpg" alt="cart image" class="card-img-top">
                <p class="card-text font-size-14  py-1">Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis non iste sequi cupiditate tempora iure. Velit accusamus saepe harum sed.</p>
                <a href="#" class="color-second text-left">Go somewhere</a>
              </div>
            </div>
            <div class="item">
              <div class="card border-0 font-rale mr-5" style="width: 30rem;">
                <h5 class="card-title font-size-16">Upcoming Books</h5>
                <img src="./assets/blogs/blog-3.jpg" alt="cart image" class="card-img-top">
                <p class="card-text font-size-14  py-1">Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis non iste sequi cupiditate tempora iure. Velit accusamus saepe harum sed.</p>
                <a href="#" class="color-second text-left">Go somewhere</a>
              </div>
            </div>
            <div class="item">
              <div class="card border-0 font-rale mr-5" style="width: 30rem;">
                <h5 class="card-title font-size-16">Upcoming Books</h5>
                <img src="./assets/blogs/blog-4.jpg" alt="cart image" class="card-img-top">
                <p class="card-text font-size-14  py-1">Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis non iste sequi cupiditate tempora iure. Velit accusamus saepe harum sed.</p>
                <a href="#" class="color-second text-left">Go somewhere</a>
              </div>
            </div>
            <div class="item">
              <div class="card border-0 font-rale mr-5" style="width: 30rem;">
                <h5 class="card-title font-size-16">Upcoming Books</h5>
                <img src="./assets/blogs/blog1.jpg" alt="cart image" class="card-img-top">
                <p class="card-text font-size-14  py-1">Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis non iste sequi cupiditate tempora iure. Velit accusamus saepe harum sed.</p>
                <a href="#" class="color-second text-left">Go somewhere</a>
              </div>
            </div>
            
          </div>
        </div>
      </section>
    <!-- !Blogs -->
