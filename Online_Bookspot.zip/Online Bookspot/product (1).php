<?php
// include header.php file
include ('header.php');
?>  
<?php
/*  include books section */
include ('Template/books.php');
/*  include books section */

/*  include top sale section */
include ('Template/_top-sale.php');
/*  include top sale section */
?>

<?php
// include footer.php file
include ('Footer.php');
?>
