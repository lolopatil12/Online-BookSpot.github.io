<?php
// include header.php file
include ('header.php');
?>    
<br>
<br>
     <?php
    /*  include blog area  */
         include ('Template/_blogs.php');
    /*  include blog area  */
    ?>
<?php
// include footer.php file
include ('Footer.php');
?>